import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

// =====================================================================
//  Colors / Theme
// =====================================================================
class C {
  static const bg = Color(0xFF070D1F); // آبی فوق تیره (پس‌زمینه)
  static const black = Color(0xFF000000);
  static const surface = Color(0xFF0F1A38);
  static const surface2 = Color(0xFF16254D);
  static const blue = Color(0xFF2979FF);
  static const green = Color(0xFF00E676);
  static const white = Color(0xFFFFFFFF);
  static const muted = Color(0xFF8FA0C8);
  static const red = Color(0xFFFF5252);
}

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: C.bg,
    colorScheme: const ColorScheme.dark(
      primary: C.green,
      secondary: C.blue,
      surface: C.surface,
      onPrimary: C.black,
      onSurface: C.white,
      error: C.red,
    ),
    appBarTheme: const AppBarTheme(backgroundColor: C.black, elevation: 0),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: C.black.withValues(alpha: 0.35),
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      labelStyle: const TextStyle(color: C.muted, fontSize: 13),
      hintStyle: TextStyle(color: C.muted.withValues(alpha: 0.6), fontSize: 13),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: C.blue.withValues(alpha: 0.35)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: C.blue.withValues(alpha: 0.35)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: C.green, width: 1.4),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size(0, 38),
        padding: const EdgeInsets.symmetric(horizontal: 14),
        textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(0, 38),
        padding: const EdgeInsets.symmetric(horizontal: 14),
        textStyle: const TextStyle(fontSize: 13),
        side: BorderSide(color: C.blue.withValues(alpha: 0.6)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    ),
  );
}

// =====================================================================
//  Helpers
// =====================================================================
class Fmt {
  static String size(num? b) {
    if (b == null || b <= 0) return '؟';
    const u = ['B', 'KB', 'MB', 'GB'];
    var v = b.toDouble();
    var i = 0;
    while (v >= 1024 && i < u.length - 1) {
      v /= 1024;
      i++;
    }
    return '${v.toStringAsFixed(i == 0 ? 0 : 1)} ${u[i]}';
  }

  static String dur(int? s) {
    if (s == null || s < 0) return '';
    final h = s ~/ 3600, m = (s % 3600) ~/ 60, sec = s % 60;
    String two(int n) => n.toString().padLeft(2, '0');
    return h > 0 ? '$h:${two(m)}:${two(sec)}' : '${two(m)}:${two(sec)}';
  }
}

String sanitize(String s) {
  var r = s.replaceAll(RegExp(r'[\\/:*?"<>|\r\n]'), '_').trim();
  if (r.length > 120) r = r.substring(0, 120);
  return r.isEmpty ? 'video' : r;
}

const _directExts = [
  '.mp4', '.mkv', '.avi', '.mov', '.webm', '.flv', '.ts', '.m4v', '.wmv',
  '.mp3', '.m4a', '.aac', '.wav', '.ogg', '.flac', '.opus',
];

String _urlPath(String url) {
  final u = Uri.tryParse(url);
  return (u?.path ?? url).toLowerCase();
}

bool isDirectLink(String url) => _directExts.any(_urlPath(url).endsWith);

String extOf(String url) {
  final p = _urlPath(url);
  for (final e in _directExts) {
    if (p.endsWith(e)) return e;
  }
  return '';
}

String nameFromUrl(String url) {
  final u = Uri.tryParse(url);
  final seg = (u != null && u.pathSegments.isNotEmpty)
      ? u.pathSegments.last
      : 'file';
  return sanitize(Uri.decodeComponent(seg));
}

String cleanError(Object e) {
  String s;
  if (e is PlatformException) {
    s = e.message ?? e.code;
  } else {
    s = e.toString().replaceFirst('Exception: ', '');
  }
  final lines =
      s.split('\n').map((l) => l.trim()).where((l) => l.isNotEmpty).toList();
  if (lines.isEmpty) return 'خطای نامشخص';
  final err = lines.lastWhere((l) => l.startsWith('ERROR'),
      orElse: () => lines.last);
  return err.length > 200 ? err.substring(0, 200) : err;
}

final bool isAndroid = Platform.isAndroid;

Future<void> openFolder(String dir) async {
  try {
    if (Platform.isWindows) {
      await Process.run('explorer', [dir]);
    } else if (Platform.isMacOS) {
      await Process.run('open', [dir]);
    } else if (Platform.isLinux) {
      await Process.run('xdg-open', [dir]);
    }
  } catch (_) {}
}

/// پل ارتباطی با کد کاتلین (فقط اندروید)
class Native {
  static const _m = MethodChannel('md/native');
  static const _e = EventChannel('md/progress');

  static Stream<dynamic> get progress => _e.receiveBroadcastStream();

  static Future<T?> call<T>(String method, [Map<String, dynamic>? args]) =>
      _m.invokeMethod<T>(method, args);

  static Future<Map<String, dynamic>?> callMap(String method,
          [Map<String, dynamic>? args]) =>
      _m.invokeMapMethod<String, dynamic>(method, args);
}

// =====================================================================
//  Models
// =====================================================================
enum DlStatus { waiting, downloading, processing, done, error, cancelled }

class QualityOption {
  final String label;
  final String selector;
  final bool audioOnly;
  final int? bytes;
  const QualityOption(this.label, this.selector,
      {this.audioOnly = false, this.bytes});
}

class VideoInfo {
  final String url;
  final String title;
  final String? thumbnail;
  final int? duration;
  final String? uploader;
  final bool isDirect;
  final List<QualityOption> options;
  const VideoInfo({
    required this.url,
    required this.title,
    required this.options,
    required this.isDirect,
    this.thumbnail,
    this.duration,
    this.uploader,
  });
}

int _idCounter = 0;

class DownloadItem extends ChangeNotifier {
  DownloadItem({
    required this.info,
    required this.name,
    required this.dir,
    required this.quality,
  }) : id = 'dl_${DateTime.now().microsecondsSinceEpoch}_${_idCounter++}';

  final String id;
  final VideoInfo info;
  final String name;
  final String dir;
  final QualityOption quality;

  DlStatus status = DlStatus.waiting;
  bool queued = false;
  double progress = 0;
  String speed = '';
  String eta = '';
  String? error;
  String? filePath;
  String? publishedUri; // اندروید
  String? mime; // اندروید

  CancelToken? cancelToken;
  Process? process; // دسکتاپ
  bool cancelRequested = false;

  bool _disposed = false;
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);

  bool get active =>
      status == DlStatus.downloading || status == DlStatus.processing;
  bool get finished =>
      status == DlStatus.done ||
      status == DlStatus.error ||
      status == DlStatus.cancelled;

  /// آپدیت UI با محدودیت سرعت (برای جلوگیری از لَگ)
  void touch({bool force = false}) {
    final now = DateTime.now();
    if (force || now.difference(_last).inMilliseconds > 150) {
      _last = now;
      notifyListeners();
    }
  }

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}

// =====================================================================
//  yt-dlp info parsing (مشترک بین دسکتاپ و اندروید)
// =====================================================================
VideoInfo parseInfo(String url, String raw) {
  final start = raw.indexOf('{');
  final end = raw.lastIndexOf('}');
  if (start < 0 || end <= start) {
    throw Exception('پاسخ نامعتبر از yt-dlp');
  }
  final j = jsonDecode(raw.substring(start, end + 1)) as Map<String, dynamic>;
  final formats = (j['formats'] as List?) ?? const [];

  final videoSizes = <int, int>{}; // height -> بزرگ‌ترین حجم
  int? bestAudio;
  for (final f in formats) {
    if (f is! Map) continue;
    final size = (f['filesize'] ?? f['filesize_approx']) as num?;
    final vcodec = f['vcodec'];
    final acodec = f['acodec'];
    final h = f['height'];
    if (vcodec != null && vcodec != 'none' && h is int) {
      final cur = videoSizes[h] ?? 0;
      videoSizes[h] = (size?.toInt() ?? 0) > cur ? size!.toInt() : cur;
    } else if (acodec != null && acodec != 'none') {
      if (size != null && (bestAudio == null || size > bestAudio)) {
        bestAudio = size.toInt();
      }
    }
  }

  final heights = videoSizes.keys.toList()..sort((a, b) => b.compareTo(a));
  int? est(int h) {
    final v = videoSizes[h] ?? 0;
    if (v == 0) return null;
    return v + (bestAudio ?? 0);
  }

  final options = <QualityOption>[
    QualityOption('بهترین کیفیت', 'bv*+ba/b',
        bytes: heights.isEmpty ? null : est(heights.first)),
    for (final h in heights)
      QualityOption('${h}p', 'bv*[height<=$h]+ba/b[height<=$h]',
          bytes: est(h)),
    QualityOption('فقط صدا (MP3)', 'ba/b', audioOnly: true, bytes: bestAudio),
  ];

  return VideoInfo(
    url: url,
    title: (j['title'] ?? 'video').toString(),
    thumbnail: j['thumbnail']?.toString(),
    duration: (j['duration'] as num?)?.toInt(),
    uploader: (j['uploader'] ?? j['channel'])?.toString(),
    isDirect: false,
    options: options,
  );
}

// =====================================================================
//  Extractors (دسکتاپ: Process / اندروید: کد کاتلین)
// =====================================================================
abstract class Extractor {
  static final Extractor instance =
      isAndroid ? AndroidExtractor() : DesktopExtractor();

  String? lastInitError;

  Future<bool> available();
  Future<String> infoJson(String url);
  Future<void> download(DownloadItem it);
  void cancel(DownloadItem it);
}

class DesktopExtractor extends Extractor {
  static final _ansi = RegExp(r'\x1B\[[0-9;]*m');

  @override
  Future<bool> available() async {
    if (!(Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      return false;
    }
    try {
      final r = await Process.run('yt-dlp', ['--version']);
      return r.exitCode == 0;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<String> infoJson(String url) async {
    ProcessResult r;
    try {
      r = await Process.run(
        'yt-dlp',
        ['-J', '--no-playlist', '--no-warnings', url],
        stdoutEncoding: utf8,
        stderrEncoding: utf8,
      );
    } on ProcessException {
      throw Exception('yt-dlp پیدا نشد. اول نصبش کن.');
    }
    if (r.exitCode != 0) {
      throw Exception(r.stderr.toString());
    }
    return r.stdout as String;
  }

  @override
  void cancel(DownloadItem it) => it.process?.kill();

  @override
  Future<void> download(DownloadItem it) async {
    final q = it.quality;
    final args = <String>[
      '--no-playlist',
      '--newline',
      '--no-warnings',
      '--concurrent-fragments', '4',
      '--retries', '10',
      '--fragment-retries', '10',
      '-f', q.selector,
      if (q.audioOnly) ...['-x', '--audio-format', 'mp3']
      else ...['--merge-output-format', 'mp4'],
      '--progress-template',
      'download:PROG|%(progress._percent_str)s|%(progress._speed_str)s|%(progress._eta_str)s',
      '-o',
      '${it.dir}${Platform.pathSeparator}${it.name.replaceAll('%', '%%')}.%(ext)s',
      it.info.url,
    ];

    final Process p;
    try {
      p = await Process.start('yt-dlp', args);
    } on ProcessException {
      throw Exception('yt-dlp پیدا نشد. اول نصبش کن.');
    }
    it.process = p;

    final errBuf = StringBuffer();

    final outDone = p.stdout
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen((raw) {
      final line = raw.replaceAll(_ansi, '').trim();
      if (line.startsWith('PROG|')) {
        final parts = line.split('|');
        final pct = double.tryParse(parts[1].replaceAll('%', '').trim());
        if (pct != null) it.progress = (pct / 100).clamp(0.0, 1.0);
        it.speed = parts.length > 2 ? _na(parts[2]) : '';
        it.eta = parts.length > 3 ? _na(parts[3]) : '';
        it.touch();
      } else if (line.startsWith('[Merger]') ||
          line.startsWith('[ExtractAudio]') ||
          line.startsWith('[VideoConvertor]')) {
        it.status = DlStatus.processing;
        it.progress = 1;
        it.speed = '';
        it.eta = '';
        it.touch(force: true);
      }
    }).asFuture();

    final errDone =
        p.stderr.transform(utf8.decoder).listen(errBuf.write).asFuture();

    final code = await p.exitCode;
    await Future.wait([outDone, errDone]);
    it.process = null;

    if (it.cancelRequested) return;
    if (code != 0) {
      throw Exception(errBuf.toString());
    }
  }

  String _na(String s) {
    final t = s.trim();
    return (t == 'N/A' || t == 'Unknown') ? '' : t;
  }
}

class AndroidExtractor extends Extractor {
  @override
  Future<bool> available() async {
    try {
      await Native.call('init');
      return true;
    } catch (e) {
      lastInitError = cleanError(e);
      return false;
    }
  }

  @override
  Future<String> infoJson(String url) async {
    final r = await Native.call<String>('info', {'url': url});
    return r ?? '';
  }

  @override
  void cancel(DownloadItem it) {
    Native.call('cancel', {'id': it.id}).catchError((_) => null);
  }

  @override
  Future<void> download(DownloadItem it) async {
    final q = it.quality;
    final path = await Native.call<String>('download', {
      'id': it.id,
      'url': it.info.url,
      'format': q.selector,
      'audioOnly': q.audioOnly,
      'dir': it.dir,
      'name': it.name,
    });
    if (path == null || path.isEmpty) {
      throw Exception('فایل خروجی پیدا نشد');
    }
    it.filePath = path;
  }
}

// =====================================================================
//  Info service
// =====================================================================
class InfoService {
  static final _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 20),
    headers: {'User-Agent': 'Mozilla/5.0 MultiDownloader'},
  ));

  static Future<VideoInfo> fetch(String url) async {
    if (isDirectLink(url)) return _direct(url);
    try {
      return parseInfo(url, await Extractor.instance.infoJson(url));
    } catch (e) {
      // شاید لینک مستقیم بدون پسوند باشد
      final d = await _tryDirectByHeader(url);
      if (d != null) return d;
      rethrow;
    }
  }

  static Future<VideoInfo> _direct(String url) async {
    int? bytes;
    try {
      final r = await _dio.head(url);
      bytes = int.tryParse(r.headers.value('content-length') ?? '');
    } catch (_) {}
    return VideoInfo(
      url: url,
      title: nameFromUrl(url),
      isDirect: true,
      options: [QualityOption('کیفیت اصلی فایل', '', bytes: bytes)],
    );
  }

  static Future<VideoInfo?> _tryDirectByHeader(String url) async {
    try {
      final r = await _dio.head(url);
      final type = r.headers.value('content-type') ?? '';
      if (type.startsWith('video/') || type.startsWith('audio/')) {
        final bytes = int.tryParse(r.headers.value('content-length') ?? '');
        final sub = type.split('/').last.split(';').first;
        return VideoInfo(
          url: url,
          title: '${nameFromUrl(url)}.$sub',
          isDirect: true,
          options: [QualityOption('کیفیت اصلی فایل', '', bytes: bytes)],
        );
      }
    } catch (_) {}
    return null;
  }
}

// =====================================================================
//  Download manager
// =====================================================================
class DownloadManager extends ChangeNotifier {
  final List<DownloadItem> items = [];
  int maxConcurrent = isAndroid ? 2 : 3;
  String saveDir = ''; // اندروید: پوشه‌ی موقت کار

  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 20),
    headers: {'User-Agent': 'Mozilla/5.0 MultiDownloader'},
  ));

  /// مسیری که به کاربر نشون داده می‌شه
  String get displayDir => isAndroid ? 'Downloads/MultiDownloader' : saveDir;

  Future<void> init() async {
    if (isAndroid) {
      Native.progress.listen(_onNative, onError: (_) {});
      Directory? d;
      try {
        d = await getExternalStorageDirectory();
      } catch (_) {}
      d ??= await getTemporaryDirectory();
      saveDir = '${d.path}${Platform.pathSeparator}tmp';
    } else {
      try {
        final d = await getDownloadsDirectory();
        saveDir = d?.path ?? _homeFallback();
      } catch (_) {
        saveDir = _homeFallback();
      }
    }
    notifyListeners();
  }

  String _homeFallback() {
    final home = Platform.environment['USERPROFILE'] ??
        Platform.environment['HOME'] ??
        '.';
    return '$home${Platform.pathSeparator}Downloads';
  }

  void setDir(String d) {
    saveDir = d;
    notifyListeners();
  }

  void setConcurrent(int n) {
    maxConcurrent = n;
    _pump();
    notifyListeners();
  }

  void add(DownloadItem it) {
    items.add(it);
    notifyListeners();
  }

  void start(DownloadItem it) {
    if (it.status == DlStatus.waiting) {
      it.queued = true;
      it.touch(force: true);
      _pump();
    }
  }

  void startAll() {
    for (final it in items) {
      if (it.status == DlStatus.waiting) it.queued = true;
    }
    _pump();
  }

  void retry(DownloadItem it) {
    if (!it.finished || it.status == DlStatus.done) return;
    it.status = DlStatus.waiting;
    it.queued = true;
    it.cancelRequested = false;
    it.progress = 0;
    it.error = null;
    it.touch(force: true);
    _pump();
  }

  void cancel(DownloadItem it) {
    if (it.finished) return;
    it.cancelRequested = true;
    if (it.info.isDirect) {
      it.cancelToken?.cancel();
    } else {
      Extractor.instance.cancel(it);
    }
    if (it.status == DlStatus.waiting) {
      it.queued = false;
      it.status = DlStatus.cancelled;
    }
    it.touch(force: true);
  }

  void cancelAll() {
    for (final it in items) {
      cancel(it);
    }
  }

  void remove(DownloadItem it) {
    cancel(it);
    items.remove(it);
    it.dispose();
    notifyListeners();
  }

  void clearFinished() {
    final done = items.where((i) => i.finished).toList();
    for (final it in done) {
      items.remove(it);
      it.dispose();
    }
    notifyListeners();
  }

  void _pump() {
    var running = items.where((i) => i.active).length;
    for (final it in items) {
      if (running >= maxConcurrent) break;
      if (it.queued && it.status == DlStatus.waiting) {
        running++;
        _run(it);
      }
    }
  }

  Future<void> _run(DownloadItem it) async {
    it.status = DlStatus.downloading;
    it.touch(force: true);
    _syncService();
    try {
      await Directory(it.dir).create(recursive: true);
      if (it.info.isDirect) {
        await _direct(it);
      } else {
        await Extractor.instance.download(it);
      }
      if (it.cancelRequested) {
        it.status = DlStatus.cancelled;
      } else {
        if (isAndroid) await _publish(it);
        it.status = DlStatus.done;
        it.progress = 1;
      }
    } catch (e) {
      if (it.cancelRequested ||
          (e is DioException && CancelToken.isCancel(e))) {
        it.status = DlStatus.cancelled;
      } else {
        it.status = DlStatus.error;
        it.error = cleanError(e);
      }
    }
    it.speed = '';
    it.eta = '';
    it.touch(force: true);
    _syncService();
    _pump();
  }

  // ---------- اندروید: انتقال به Downloads ----------
  Future<void> _publish(DownloadItem it) async {
    final path = it.filePath;
    if (path == null) throw Exception('فایل خروجی پیدا نشد');
    it.status = DlStatus.processing;
    it.progress = 1;
    it.speed = '';
    it.eta = '';
    it.touch(force: true);
    final r = await Native.callMap('publish', {'path': path});
    it.publishedUri = r?['uri'] as String?;
    it.mime = r?['mime'] as String?;
  }

  Future<void> _syncService() async {
    if (!isAndroid) return;
    try {
      final n = items.where((i) => i.active).length;
      if (n > 0) {
        await Native.call('service', {'text': '$n دانلود در حال انجام'});
      } else {
        await Native.call('service', {'stop': true});
      }
    } catch (_) {}
  }

  // ---------- رویداد پیشرفت از کاتلین ----------
  void _onNative(dynamic e) {
    if (e is! Map) return;
    final it = items.where((i) => i.id == e['id']).firstOrNull;
    if (it == null || it.finished) return;

    final line = (e['line'] ?? '').toString();
    if (line.startsWith('[Merger]') ||
        line.startsWith('[ExtractAudio]') ||
        line.startsWith('[VideoConvertor]')) {
      it.status = DlStatus.processing;
      it.progress = 1;
      it.speed = '';
      it.eta = '';
      it.touch(force: true);
      return;
    }
    if (it.status == DlStatus.processing) return;

    final p = (e['progress'] as num?)?.toDouble() ?? -1;
    if (p >= 0) it.progress = (p / 100).clamp(0.0, 1.0);
    it.speed = (e['speed'] ?? '').toString();
    final eta = (e['eta'] as num?)?.toInt() ?? -1;
    it.eta = eta >= 0 ? Fmt.dur(eta) : '';
    it.touch();
  }

  // ---------- لینک مستقیم ----------
  Future<void> _direct(DownloadItem it) async {
    final path = '${it.dir}${Platform.pathSeparator}${it.name}';
    it.filePath = path;
    it.cancelToken = CancelToken();
    final sw = Stopwatch()..start();
    var lastBytes = 0;
    var lastMs = 0;

    await _dio.download(
      it.info.url,
      path,
      cancelToken: it.cancelToken,
      deleteOnError: true,
      onReceiveProgress: (received, total) {
        if (total > 0) it.progress = received / total;
        final ms = sw.elapsedMilliseconds;
        if (ms - lastMs >= 500) {
          final bps = (received - lastBytes) * 1000 / (ms - lastMs);
          it.speed = '${Fmt.size(bps)}/s';
          if (total > 0 && bps > 0) {
            it.eta = Fmt.dur(((total - received) / bps).round());
          }
          lastBytes = received;
          lastMs = ms;
        }
        it.touch();
      },
    );
  }
}

// =====================================================================
//  App
// =====================================================================
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Multi Downloader',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      builder: (context, child) =>
          Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  final manager = DownloadManager();
  final urlCtrl = TextEditingController();
  final nameCtrl = TextEditingController();

  bool? engineOk;
  bool analyzing = false;
  String? error;
  VideoInfo? info;
  QualityOption? selected;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    manager.init();
    Extractor.instance.available().then((v) {
      if (mounted) setState(() => engineOk = v);
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkShared());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _checkShared();
  }

  /// لینکی که از برنامه‌ی دیگه (مثلاً یوتیوب) «اشتراک‌گذاری» شده
  Future<void> _checkShared() async {
    if (!isAndroid) return;
    try {
      final text = await Native.call<String>('shared');
      if (text == null || text.isEmpty) return;
      final m = RegExp(r'https?://\S+').firstMatch(text);
      if (m == null || !mounted) return;
      urlCtrl.text = m.group(0)!;
      analyze();
    } catch (_) {}
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    manager.cancelAll();
    urlCtrl.dispose();
    nameCtrl.dispose();
    super.dispose();
  }

  Future<void> paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    if (d?.text != null) {
      final m = RegExp(r'https?://\S+').firstMatch(d!.text!);
      urlCtrl.text = (m?.group(0) ?? d.text!).trim();
      analyze();
    }
  }

  Future<void> analyze() async {
    FocusManager.instance.primaryFocus?.unfocus();
    final url = urlCtrl.text.trim();
    if (url.isEmpty || !(Uri.tryParse(url)?.hasScheme ?? false)) {
      setState(() => error = 'یه لینک معتبر وارد کن (با http یا https).');
      return;
    }
    setState(() {
      analyzing = true;
      error = null;
      info = null;
      selected = null;
    });
    try {
      final r = await InfoService.fetch(url);
      if (!mounted) return;
      setState(() {
        info = r;
        selected = r.options.first;
        nameCtrl.text = sanitize(r.title);
      });
    } catch (e) {
      if (mounted) setState(() => error = cleanError(e));
    } finally {
      if (mounted) setState(() => analyzing = false);
    }
  }

  Future<void> pickDir() async {
    final d = await FilePicker.platform.getDirectoryPath();
    if (d != null) manager.setDir(d);
  }

  void addToQueue({required bool startNow}) {
    final i = info, q = selected;
    if (i == null || q == null) return;
    var name = sanitize(nameCtrl.text.trim().isEmpty ? i.title : nameCtrl.text);
    if (i.isDirect && !name.contains('.')) name += extOf(i.url);

    final item = DownloadItem(
      info: i,
      name: name,
      dir: manager.saveDir,
      quality: q,
    );
    manager.add(item);
    if (startNow) manager.start(item);

    setState(() {
      info = null;
      selected = null;
      urlCtrl.clear();
      nameCtrl.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 52,
        title: Row(children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [C.green, C.blue]),
              borderRadius: BorderRadius.circular(8),
            ),
            child:
                const Icon(Icons.download_rounded, size: 18, color: C.black),
          ),
          const SizedBox(width: 10),
          const Text('Multi Downloader',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        ]),
      ),
      body: SafeArea(
        top: false,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 920),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
              child: Column(children: [
                Expanded(
                  child: ListView(
                    children: [
                      if (engineOk == false) _warningBanner(),
                      _inputCard(),
                      if (analyzing) _loadingBar(),
                      if (info != null) _previewCard(info!),
                      const SizedBox(height: 12),
                      _queueSection(),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                _bottomBar(),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  // ---------- Widgets ----------
  Widget _warningBanner() => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: C.red.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: C.red.withValues(alpha: 0.5)),
        ),
        child: Text(
          isAndroid
              ? '⚠ موتور دانلود آماده نشد'
                  '${Extractor.instance.lastInitError != null ? ': ${Extractor.instance.lastInitError}' : '.'}'
              : '⚠ yt-dlp روی سیستم پیدا نشد. لینک‌های مستقیم کار می‌کنن ولی '
                  'برای یوتیوب/اینستا/... باید yt-dlp و ffmpeg نصب باشه.',
          style: const TextStyle(fontSize: 12.5),
        ),
      );

  Widget _card({required Widget child}) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: C.blue.withValues(alpha: 0.25)),
        ),
        child: child,
      );

  Widget _inputCard() => _card(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(
            controller: urlCtrl,
            textDirection: TextDirection.ltr,
            keyboardType: TextInputType.url,
            onSubmitted: (_) => analyze(),
            style: const TextStyle(fontSize: 13.5),
            decoration: const InputDecoration(
              labelText: 'آدرس ویدیو',
              hintText: 'لینک یوتیوب، اینستاگرام، توییتر، لینک مستقیم ...',
              prefixIcon: Icon(Icons.link, size: 18, color: C.blue),
            ),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: analyzing ? null : analyze,
                icon: const Icon(Icons.search, size: 17),
                label: const Text('تحلیل لینک'),
                style: FilledButton.styleFrom(
                    backgroundColor: C.blue, foregroundColor: C.white),
              ),
            ),
            const SizedBox(width: 8),
            OutlinedButton.icon(
              onPressed: analyzing ? null : paste,
              icon: const Icon(Icons.content_paste, size: 17),
              label: const Text('چسباندن'),
            ),
          ]),
          if (error != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text('❌ $error',
                  style: const TextStyle(color: C.red, fontSize: 12.5)),
            ),
        ]),
      );

  Widget _loadingBar() => Padding(
        padding: const EdgeInsets.only(top: 10),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: const LinearProgressIndicator(
              minHeight: 4, color: C.green, backgroundColor: C.surface2),
        ),
      );

  Widget _thumb(String? url, {double w = 110, double h = 62}) => ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: SizedBox(
          width: w,
          height: h,
          child: url == null
              ? _thumbPlaceholder()
              : Image.network(url,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => _thumbPlaceholder()),
        ),
      );

  Widget _thumbPlaceholder() => Container(
        color: C.black,
        child: const Icon(Icons.movie_outlined, color: C.muted),
      );

  Widget _previewCard(VideoInfo i) => Padding(
        padding: const EdgeInsets.only(top: 10),
        child: _card(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _thumb(i.thumbnail),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(i.title,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14)),
                      const SizedBox(height: 4),
                      Text(
                        [
                          if (i.uploader != null) i.uploader!,
                          if (i.duration != null) Fmt.dur(i.duration),
                        ].join('  •  '),
                        style: const TextStyle(color: C.muted, fontSize: 12),
                      ),
                    ]),
              ),
            ]),
            const SizedBox(height: 12),
            const Text('کیفیت رو انتخاب کن:',
                style: TextStyle(color: C.muted, fontSize: 12.5)),
            const SizedBox(height: 6),
            Wrap(spacing: 6, runSpacing: 6, children: [
              for (final o in i.options)
                ChoiceChip(
                  visualDensity: VisualDensity.compact,
                  label: Text(
                    o.bytes != null
                        ? '${o.label}  •  ${Fmt.size(o.bytes)}'
                        : o.label,
                    style: TextStyle(
                        fontSize: 12,
                        color: selected == o ? C.black : C.white),
                  ),
                  selected: selected == o,
                  selectedColor: C.green,
                  backgroundColor: C.surface2,
                  side: BorderSide.none,
                  showCheckmark: false,
                  onSelected: (_) => setState(() => selected = o),
                ),
            ]),
            const SizedBox(height: 12),
            TextField(
              controller: nameCtrl,
              style: const TextStyle(fontSize: 13.5),
              decoration: const InputDecoration(
                labelText: 'اسم فایل',
                prefixIcon: Icon(Icons.edit, size: 17, color: C.blue),
              ),
            ),
            const SizedBox(height: 8),
            AnimatedBuilder(
              animation: manager,
              builder: (_, __) => Row(children: [
                const Icon(Icons.folder, size: 18, color: C.green),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(manager.displayDir,
                      textDirection: TextDirection.ltr,
                      textAlign: TextAlign.right,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: C.muted, fontSize: 12)),
                ),
                if (!isAndroid)
                  OutlinedButton(
                      onPressed: pickDir, child: const Text('تغییر مسیر')),
              ]),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => addToQueue(startNow: true),
                  icon: const Icon(Icons.download, size: 17),
                  label: const Text('دانلود'),
                  style: FilledButton.styleFrom(
                      backgroundColor: C.green, foregroundColor: C.black),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => addToQueue(startNow: false),
                  icon: const Icon(Icons.playlist_add, size: 17),
                  label: const Text('افزودن به صف'),
                ),
              ),
            ]),
          ]),
        ),
      );

  Widget _queueSection() => AnimatedBuilder(
        animation: manager,
        builder: (_, __) {
          if (manager.items.isEmpty) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 40),
              child: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.cloud_download_outlined,
                      size: 56, color: C.blue.withValues(alpha: 0.5)),
                  const SizedBox(height: 8),
                  const Text('صف دانلود خالیه',
                      style: TextStyle(color: C.muted)),
                ]),
              ),
            );
          }
          return Column(children: [
            for (final it in manager.items)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: QueueTile(
                    key: ObjectKey(it), item: it, manager: manager),
              ),
          ]);
        },
      );

  Widget _bottomBar() => AnimatedBuilder(
        animation: manager,
        builder: (_, __) => Wrap(
          spacing: 8,
          runSpacing: 8,
          alignment: WrapAlignment.center,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            FilledButton.icon(
              onPressed: manager.startAll,
              icon: const Icon(Icons.play_arrow_rounded, size: 18),
              label: const Text('شروع همه'),
              style: FilledButton.styleFrom(
                  backgroundColor: C.green, foregroundColor: C.black),
            ),
            FilledButton.icon(
              onPressed: manager.cancelAll,
              icon: const Icon(Icons.stop_rounded, size: 18),
              label: const Text('توقف همه'),
              style: FilledButton.styleFrom(
                  backgroundColor: C.blue, foregroundColor: C.white),
            ),
            OutlinedButton.icon(
              onPressed: manager.clearFinished,
              icon: const Icon(Icons.cleaning_services, size: 16),
              label: Text(isAndroid ? 'پاک کردن' : 'پاک کردن تمام‌شده‌ها'),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: C.surface,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: C.blue.withValues(alpha: 0.35)),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<int>(
                  value: manager.maxConcurrent,
                  isDense: true,
                  dropdownColor: C.surface2,
                  style: const TextStyle(fontSize: 12.5, color: C.white),
                  items: [
                    for (final n in [1, 2, 3, 4, 5])
                      DropdownMenuItem(
                          value: n, child: Text('$n هم‌زمان')),
                  ],
                  onChanged: (v) {
                    if (v != null) manager.setConcurrent(v);
                  },
                ),
              ),
            ),
            if (!isAndroid)
              OutlinedButton.icon(
                onPressed: () {
                  manager.cancelAll();
                  exit(0);
                },
                icon: const Icon(Icons.close, size: 16),
                label: const Text('خروج'),
                style: OutlinedButton.styleFrom(foregroundColor: C.muted),
              ),
          ],
        ),
      );
}

// =====================================================================
//  Queue tile
// =====================================================================
class QueueTile extends StatelessWidget {
  const QueueTile({super.key, required this.item, required this.manager});
  final DownloadItem item;
  final DownloadManager manager;

  Color get _color {
    switch (item.status) {
      case DlStatus.done:
        return C.green;
      case DlStatus.error:
        return C.red;
      case DlStatus.cancelled:
        return C.muted;
      case DlStatus.processing:
        return C.white;
      default:
        return C.blue;
    }
  }

  String get _label {
    switch (item.status) {
      case DlStatus.waiting:
        return item.queued ? 'در صف...' : 'آماده';
      case DlStatus.downloading:
        return 'در حال دانلود';
      case DlStatus.processing:
        return isAndroid ? 'در حال ذخیره‌سازی...' : 'در حال پردازش...';
      case DlStatus.done:
        return isAndroid ? '✅ ذخیره شد در Downloads' : '✅ تکمیل شد';
      case DlStatus.error:
        return '❌ خطا';
      case DlStatus.cancelled:
        return 'لغو شد';
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: item,
      builder: (_, __) {
        final indeterminate = item.status == DlStatus.processing;
        return Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: C.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _color.withValues(alpha: 0.35)),
          ),
          child: Row(children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: SizedBox(
                width: 64,
                height: 48,
                child: item.info.thumbnail == null
                    ? Container(
                        color: C.black,
                        child: const Icon(Icons.movie_outlined,
                            color: C.muted, size: 22))
                    : Image.network(item.info.thumbnail!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) =>
                            Container(color: C.black)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 13.5)),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: indeterminate ? null : item.progress,
                        minHeight: 5,
                        color:
                            item.status == DlStatus.done ? C.green : C.blue,
                        backgroundColor: C.surface2,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Row(children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 1),
                        decoration: BoxDecoration(
                          color: C.blue.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(item.quality.label,
                            style: const TextStyle(
                                fontSize: 10.5, color: C.white)),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          item.status == DlStatus.error
                              ? '$_label: ${item.error ?? ''}'
                              : [
                                  _label,
                                  if (item.status == DlStatus.downloading)
                                    '${(item.progress * 100).toStringAsFixed(0)}%',
                                  if (item.speed.isNotEmpty) item.speed,
                                  if (item.eta.isNotEmpty) item.eta,
                                ].join(' • '),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 11.5, color: _color),
                        ),
                      ),
                    ]),
                  ]),
            ),
            const SizedBox(width: 4),
            ..._actions(),
          ]),
        );
      },
    );
  }

  Widget _icon(IconData i, String tip, VoidCallback onTap, {Color? color}) =>
      IconButton(
        tooltip: tip,
        onPressed: onTap,
        icon: Icon(i, size: 20, color: color ?? C.white),
        visualDensity: VisualDensity.compact,
        constraints: const BoxConstraints(minWidth: 34, minHeight: 34),
        padding: EdgeInsets.zero,
      );

  List<Widget> _actions() {
    switch (item.status) {
      case DlStatus.waiting:
        return [
          if (!item.queued)
            _icon(Icons.play_arrow_rounded, 'شروع', () => manager.start(item),
                color: C.green),
          _icon(Icons.close, 'حذف', () => manager.remove(item)),
        ];
      case DlStatus.downloading:
      case DlStatus.processing:
        return [
          _icon(Icons.stop_rounded, 'توقف', () => manager.cancel(item),
              color: C.red),
        ];
      case DlStatus.done:
        return [
          if (isAndroid)
            _icon(
                Icons.play_circle_outline,
                'باز کردن',
                () => Native.call('open',
                    {'uri': item.publishedUri, 'mime': item.mime}),
                color: C.green)
          else
            _icon(Icons.folder_open, 'باز کردن پوشه',
                () => openFolder(item.dir),
                color: C.green),
          _icon(Icons.delete_outline, 'حذف از لیست',
              () => manager.remove(item)),
        ];
      case DlStatus.error:
      case DlStatus.cancelled:
        return [
          _icon(Icons.refresh, 'تلاش مجدد', () => manager.retry(item),
              color: C.blue),
          _icon(Icons.delete_outline, 'حذف از لیست',
              () => manager.remove(item)),
        ];
    }
  }
}
