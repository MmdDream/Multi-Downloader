package com.multidl.multi_downloader

import android.Manifest
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val pool = Executors.newCachedThreadPool()
    private var sink: EventChannel.EventSink? = null
    private var sharedText: String? = null

    @Volatile
    private var ready = false
    private val initLock = Any()

    // ------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        requestNeededPermissions()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            sharedText = i.getStringExtra(Intent.EXTRA_TEXT)
        }
    }

    private fun requestNeededPermissions() {
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 77)
    }

    // ------------------------------------------------------------
    private fun ensureInit() {
        synchronized(initLock) {
            if (ready) return
            YoutubeDL.getInstance().init(applicationContext)
            FFmpeg.getInstance().init(applicationContext)
            ready = true
        }
    }

    private fun runAsync(result: MethodChannel.Result, block: () -> Any?) {
        pool.execute {
            try {
                val r = block()
                mainHandler.post { result.success(r) }
            } catch (e: Throwable) {
                mainHandler.post { result.error("ERR", e.message ?: e.toString(), null) }
            }
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        EventChannel(messenger, "md/progress").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                sink = events
            }

            override fun onCancel(arguments: Any?) {
                sink = null
            }
        })

        MethodChannel(messenger, "md/native").setMethodCallHandler { call, result ->
            when (call.method) {
                "init" -> runAsync(result) { ensureInit(); true }
                "info" -> runAsync(result) {
                    ensureInit()
                    getInfo(call.argument<String>("url")!!)
                }
                "download" -> runAsync(result) {
                    ensureInit()
                    download(call)
                }
                "cancel" -> pool.execute {
                    try {
                        YoutubeDL.getInstance().destroyProcessById(call.argument<String>("id")!!)
                    } catch (_: Throwable) {
                    }
                    mainHandler.post { result.success(true) }
                }
                "publish" -> runAsync(result) { publish(call.argument<String>("path")!!) }
                "open" -> {
                    result.success(openFile(call.argument<String>("uri"), call.argument<String>("mime")))
                }
                "service" -> {
                    try {
                        val i = Intent(this, DownloadService::class.java)
                        if (call.argument<Boolean>("stop") == true) {
                            stopService(i)
                        } else {
                            i.putExtra("text", call.argument<String>("text"))
                            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                        }
                        result.success(true)
                    } catch (e: Throwable) {
                        result.success(false)
                    }
                }
                "shared" -> {
                    result.success(sharedText)
                    sharedText = null
                }
                else -> result.notImplemented()
            }
        }
    }

    // ------------------------------------------------------------
    private fun getInfo(url: String): String {
        val req = YoutubeDLRequest(url)
        req.addOption("-J")
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        return YoutubeDL.getInstance().execute(req).out
    }

    private fun download(call: MethodCall): String {
        val id = call.argument<String>("id")!!
        val url = call.argument<String>("url")!!
        val format = call.argument<String>("format")!!
        val audioOnly = call.argument<Boolean>("audioOnly") ?: false
        val dir = call.argument<String>("dir")!!
        val name = call.argument<String>("name")!!

        File(dir).mkdirs()

        val req = YoutubeDLRequest(url)
        req.addOption("--no-playlist")
        req.addOption("-f", format)
        if (audioOnly) {
            req.addOption("-x")
            req.addOption("--audio-format", "mp3")
        } else {
            req.addOption("--merge-output-format", "mp4")
        }
        req.addOption("--concurrent-fragments", "4")
        req.addOption("--retries", "10")
        req.addOption("--fragment-retries", "10")
        req.addOption("--no-mtime")
        req.addOption("-o", "$dir/${name.replace("%", "%%")}.%(ext)s")

        val speedRe = Regex("at\\s+(\\S+/s)")
        try {
            YoutubeDL.getInstance().execute(req, id) { progress, eta, line ->
                val speed = speedRe.find(line)?.groupValues?.get(1) ?: ""
                mainHandler.post {
                    sink?.success(
                        mapOf(
                            "id" to id,
                            "progress" to progress.toDouble(),
                            "eta" to eta.toLong(),
                            "speed" to speed,
                            "line" to line
                        )
                    )
                }
            }
        } catch (e: Throwable) {
            cleanup(dir, name)
            throw e
        }

        val out = File(dir).listFiles { f ->
            f.isFile && f.name.startsWith("$name.") &&
                !f.name.endsWith(".part") && !f.name.endsWith(".ytdl") && !f.name.endsWith(".temp")
        }?.maxByOrNull { it.lastModified() }
            ?: throw Exception("فایل خروجی پیدا نشد")
        return out.absolutePath
    }

    private fun cleanup(dir: String, name: String) {
        try {
            File(dir).listFiles { f -> f.name.startsWith("$name.") }?.forEach { it.delete() }
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------
    /** انتقال فایل به Downloads/MultiDownloader (بدون نیاز به دسترسی در اندروید 10+) */
    private fun publish(path: String): Map<String, String?> {
        val src = File(path)
        val ext = src.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"

        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, src.name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MultiDownloader")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("ساخت فایل در Downloads ناموفق بود")
            resolver.openOutputStream(uri)!!.use { out ->
                src.inputStream().use { it.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            src.delete()
            return mapOf("uri" to uri.toString(), "mime" to mime)
        }

        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "MultiDownloader"
        )
        dir.mkdirs()
        var dst = File(dir, src.name)
        var n = 1
        while (dst.exists()) {
            dst = File(dir, "${src.nameWithoutExtension} ($n).${src.extension}")
            n++
        }
        src.copyTo(dst)
        src.delete()
        MediaScannerConnection.scanFile(this, arrayOf(dst.absolutePath), arrayOf(mime), null)
        return mapOf("uri" to null, "mime" to mime)
    }

    private fun openFile(uri: String?, mime: String?): Boolean {
        return try {
            val intent = if (uri != null) {
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(Uri.parse(uri), mime ?: "*/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            true
        } catch (e: Throwable) {
            try {
                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                true
            } catch (e2: Throwable) {
                false
            }
        }
    }
}
