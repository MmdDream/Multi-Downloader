plugins {
    id("com.android.application")
    id("kotlin-android")
    // Flutter Gradle plugin باید بعد از پلاگین‌های اندروید و کاتلین بیاد
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.multidl.multi_downloader"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }

    defaultConfig {
        applicationId = "com.multidl.multi_downloader"
        minSdk = 24 // yt-dlp-android حداقل اندروید 7 می‌خواد
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    // لازمه تا پایتون و ffmpeg داخل APK درست استخراج بشن
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    buildTypes {
        release {
            // برای تست؛ برای انتشار واقعی باید کلید خودت رو بذاری
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}

flutter {
    source = "../.."
}

dependencies {
    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")
}
